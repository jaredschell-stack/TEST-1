# Mustang Station 3 – Work Instructions

Live site: https://YOURUSERNAME.github.io/YOURREPO/

---

## Sections

- **[Preparation](#prep)**
- **[Body Prep](#body)**
- **[Hood](#hood)**
- **[Fender Extension](#fender)**

All images are embedded and the page is fully printable.